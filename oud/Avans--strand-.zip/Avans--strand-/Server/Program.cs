﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Server.ServerFiles;
namespace Server
{
    class Program
    {
        static void Main(string[] args)
        {
            new Program();
        }

        public Program()
        {
            new Server.ServerFiles.Server();
            Console.Read();
        }
    }
}
