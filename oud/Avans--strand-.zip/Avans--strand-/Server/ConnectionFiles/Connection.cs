﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Net.Sockets;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.IO;

namespace Server.ConnectionFiles
{
    class Connection
    {
        public string intent;
        private string ip;
        private int port;

        private Stream dataStream;
        public TcpClient connection;
        private StreamWriter writer;

        private Thread worker;
        private StreamListener streamlistener;
        private ITCPDataListener listener;

        public string name = "placeholder";

        public bool alive;

        public Connection(string type, TcpClient client, ITCPDataListener listener)
        {
            this.listener = listener;
            this.connection = client;
            connection.NoDelay = true;
            this.dataStream = client.GetStream();
            switch (type.ToUpper())
            {
                case "DOCTOR": type = "doctor"; break;
                case "PATIENT": type = "patient"; break;
                default: this.intent = "watcher"; break;
            }
            StartConnectionWorker();
        }

        public void SendData(string data)
        {
            try
            {
                if (writer != null && alive)
                {
                    writer.WriteLine(data);
                    writer.Flush();
                    Console.WriteLine("sent: " + data);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Could not send message: " + ex);
                this.alive = false;
            }
        }

        public void SendData(string command, JObject @object)
        {
            SendData(JsonConvert.SerializeObject(new
            {
                command = command,
                data = @object
            }));
        }

        public void SendData(string command, JArray @object)
        {
            SendData(JsonConvert.SerializeObject(new
            {
                command = command,
                data = @object
            }));
        }

        public void SendRequestDenied(string data)
        {
            SendData(JsonConvert.SerializeObject(new
            {
                command = "server/denied",
                data = new
                {
                    info = data
                }
            }));
        }

        public void SendOK()
        {
            SendData(JsonConvert.SerializeObject(new
            {
                command = "server/accepted",
                data = new
                {
                    info = "OK"
                }
            }));
        }

        public void SendOK(string args)
        {
            SendData(JsonConvert.SerializeObject(new
            {
                command = "server/accepted",
                data = new
                {
                    info = "OK",
                    origin = args
                }
            }));
        }

        private void StartConnectionWorker()
        {
            this.alive = true;
            writer = new StreamWriter(this.dataStream);
            streamlistener = new StreamListener(this, dataStream, listener);
            worker = new Thread(new ThreadStart(streamlistener.Start));
            worker.Start();
        }

        public void CloseConnection()
        {
            try
            {
                streamlistener.alive = false;
                dataStream.Flush();
                dataStream.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Could not close connection: " + ex);
            }
        }
    }
}
