﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server.ConnectionFiles
{
    interface ITCPDataListener
    {
        void OnDataReceived(string data, Connection c);
    }
}
