﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;

namespace Server.ServerFiles
{
    class ServerAccepter
    {
        private TcpListener server;
        private ISocketListener listener;
        public bool alive;
        public ServerAccepter(TcpListener server, ISocketListener listener)
        {
            this.server = server;
            this.listener = listener;
            alive = true;
            server.Start();
        }

        public void Start()
        {
            Console.WriteLine("Started socket accepting thread");
            while (alive)
            {
                try
                {
                    listener.OnSocketConnected(server.AcceptTcpClient());
                    Console.WriteLine("new socket has connected");
                }
                catch (Exception ex)
                {
                    Console.WriteLine("SocketAccepter has encountered an error: " + ex);
                    Stop();
                }
            }
        }

        public void Stop()
        {
            try
            {
                alive = false;
                server.Stop();
            }
            catch (Exception ex)
            {
                alive = false;
                Console.WriteLine("Could not stop server: " + ex);

            }
        }
    }
}
