﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using Server.ConnectionFiles;
using Server.Json;
using Server.ServerFiles;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Server.Bike;

namespace Server.ServerFiles
{
    class Server : ITCPDataListener, ISocketListener
    {
        private List<Connection> connections;
        private TcpListener server;

        private ServerAccepter accepter;
        private Thread worker;

        private List<BikeMeasurement> datapoints;


        private bool alive;

        public Server()
        {
            Console.WriteLine("Started server");
            connections = new List<Connection>();
            server = new TcpListener(IPAddress.Any, 25565);
            server.Start();
            alive = true;
            datapoints = new List<BikeMeasurement>();
            StartConnectionworker();
        }

        public void ParseData(string data, Connection c)
        {
            string id;
            Connection pc;

            dynamic message = JsonConvert.DeserializeObject(data);
            string command = message.command;
            switch (command)
            {
                case "client/disconnect":
                    c.CloseConnection();
                    DeleteConnection(c);
                    Console.WriteLine("Current active clients " + connections.Count);
                    break;
                case "client/intent":
                    id = message.data.id;
                    if (CheckIntentAvailable(id))
                    {
                        c.intent = id;
                        c.SendOK();
                    }
                    else
                        c.SendRequestDenied($"{id} already exists you are a watcher now");
                    break;
                case "client/getallpatients":
                    List<Patient> patients = JsonFileHandler.GetPatients();
                    JArray output = new JArray();
                    foreach (Patient p in patients)
                        output.Add(JToken.FromObject(p));
                    c.SendData("server/patients", output);
                    break;
                case "watcher/requestfilelist":
                    JArray list = new JArray(JsonFileHandler.GetAllOutputDataFileNames());
                    c.SendData("server/files", list);
                    break;
                case "watcher/requestdata":
                    id = message.data.file;
                    List<Bike.BikeMeasurement> measurements = JsonFileHandler.GetBikeData(id);
                    if (measurements != null)
                    {
                        JArray output1 = new JArray();
                        foreach (BikeMeasurement m in measurements)
                            output1.Add(JToken.FromObject(m));
                        c.SendData("server/data", output1);
                    }
                    else
                        c.SendRequestDenied("File not found");
                    break;
                case "doctor/starttest":
                    if (c.intent == "DOCTOR")
                    {
                        datapoints.Clear();
                        PassThroughDataToPatient(data,"doctor/starttest", c);
                        
                    } else
                    {
                        c.SendRequestDenied("You are not a doctor");
                    }
                    break;
                case "doctor/stoptest":
                    pc = FindPatientConnection();
                    if(pc != null)
                        JsonFileHandler.WriteBikeDataToOutput(datapoints,$"{DateTime.Now} + {pc.name}.json");
                    else
                        JsonFileHandler.WriteBikeDataToOutput(datapoints, $"{DateTime.Now}.json");
                    datapoints.Clear();
                    PassThroughDataToPatient(data, c);
                    break;
                case "doctor/bikesettings":
                    if (c.intent == "DOCTOR")
                        PassThroughDataToPatient(data, c);
                    else
                        c.SendRequestDenied("You are not a doctor");
                    break;
                case "doctor/setpower":
                    if (c.intent == "DOCTOR")
                        PassThroughDataToPatient(data, c);
                    else
                        c.SendRequestDenied("You are not a doctor");
                    break;
                case "doctor/settime":
                    if (c.intent == "DOCTOR")
                        PassThroughDataToPatient(data, c);
                    else
                        c.SendRequestDenied("You are not a doctor");
                    break;
                case "doctor/resetbike":
                    if (c.intent == "DOCTOR")
                        PassThroughDataToPatient(data, c);
                    else
                        c.SendRequestDenied("You are not a doctor");
                    break;
                case "doctor/patientname":
                    id = message.data.name;
                    pc = FindPatientConnection();
                    if (pc != null)
                        pc.name = id;
                    else
                        c.SendRequestDenied("No patient is connected to the server");
                    break;
                case "patient/bikedata":
                    JObject @object = message.data;
                    Bike.BikeMeasurement measurement = @object.ToObject<Bike.BikeMeasurement>();
                    datapoints.Add(measurement);
                    PassThroughDataToDoctor(data, c);
                    break;
            }
        }

        private void StartConnectionworker()
        {
            accepter = new ServerAccepter(server, this);
            worker = new Thread(new ThreadStart(accepter.Start));
            worker.Start();
        }

        public void StopServer()
        {
            accepter.Stop();
            alive = false;
        }


        #region Listeners
        public void OnDataReceived(string data, Connection c)
        {
            Console.WriteLine(data);
            ParseData(data, c);
        }

        private bool CheckIntentAvailable(string intent)
        {
            foreach(Connection c in connections)
            {
                if(c.intent == intent)
                {
                    return false;
                }
            }
            return true;

        }

        private void PassThroughDataToDoctor(string data, Connection c)
        {
            Connection doctor = FindDoctorConnection();
            if (doctor != null)
            {
                doctor.SendData(data);
                c.SendOK();
            }

            else
                c.SendRequestDenied("Doctor not found");
        }

        private void PassThroughDataToDoctor(string data, string command, Connection c)
        {
            Connection doctor = FindDoctorConnection();
            if (doctor != null)
            {
                doctor.SendData(data);
                c.SendOK(command);
            }

            else
                c.SendRequestDenied("Doctor not found");
        }

        private void PassThroughDataToPatient(string data, Connection c)
        {
            Connection patient = FindPatientConnection();
            if (patient != null)
            {
                patient.SendData(data);
                c.SendOK();
            }
            else
                c.SendRequestDenied("Patient not found");
        }

        private void PassThroughDataToPatient(string data, string command ,Connection c)
        {
            Connection patient = FindPatientConnection();
            if (patient != null)
            {
                patient.SendData(data);
                c.SendOK(command);
            }
            else
                c.SendRequestDenied("Patient not found");
        }

        private Connection FindPatientConnection()
        {
            foreach (Connection c in connections)
                if (c.intent == "PATIENT")
                    return c;
            return null;
        }

        private Connection FindDoctorConnection()
        {
            foreach (Connection c in connections)
                if (c.intent == "DOCTOR")
                    return c;
            return null;
        }

        private void DeleteConnection(Connection c)
        {
            connections.Remove(c);
        }

        public void OnSocketConnected(TcpClient client)
        {
            connections.Add(new Connection("watcher", client, this));
        }
        #endregion
    }
}
