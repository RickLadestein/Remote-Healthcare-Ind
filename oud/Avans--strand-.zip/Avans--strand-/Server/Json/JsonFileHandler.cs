﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Newtonsoft.Json;
using System.Threading.Tasks;
using Server.Bike;

namespace Server.Json
{
    class JsonFileHandler
    {
        public static Tuple<string, int> GetConfigurations(string filename, string extension)
        {
            Tuple<string, int> output = null;
            try
            {
                FileStream file = new FileStream(@"../../config/" + filename, FileMode.Open);
                StreamReader reader = new StreamReader(file);

                dynamic data = JsonConvert.DeserializeObject(reader.ReadToEnd());
                string ip = data.ip;
                int port = data.port;

                output = new Tuple<string, int>(ip, port);
                Console.WriteLine(output.ToString());
                reader.Close();
                file.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            return output;
        }

        public static bool WriteBikeDataToOutput(List<BikeMeasurement> datapoints, string outputfilename)
        {
            if (File.Exists(@"../../output/" + outputfilename))
            {
                return false;
            }

            try
            {
                FileStream file = new FileStream(@"../../output/" + outputfilename, FileMode.Create);
                StreamWriter writer = new StreamWriter(file);
                writer.WriteLine(JsonConvert.SerializeObject(datapoints));
                writer.Close();
                file.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return false;
            }
            return true;
        }

        public static List<BikeMeasurement> GetBikeData(string filename)
        {
            FileStream file = null;
            StreamReader reader = null;
            List<BikeMeasurement> output;
            try
            {
                if (!File.Exists(@"../../output/" + filename))
                {
                    Console.WriteLine($"Tried to access {filename} but file does not exist");
                    return null;
                }
                else
                {
                    file = new FileStream(@"../../output/" + filename, FileMode.Open);
                    reader = new StreamReader(file);
                    string line = reader.ReadLine();

                    if (line != null && line != "")
                        output = JsonConvert.DeserializeObject<List<BikeMeasurement>>(line);
                    else
                        output = new List<BikeMeasurement>();
                    reader.Close();
                    file.Close();
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                reader.Close();
                file.Close();
                return new List<BikeMeasurement>();
            }
            return output;
        }

        public static List<Patient> GetPatients()
        {
            FileStream file = null;
            StreamReader reader = null;
            List<Patient> output;
            try
            {
                if (!File.Exists(@"../../config/patients.json"))
                {
                    Console.WriteLine($"Tried to access patients.json but file does not exist");
                    return new List<Patient>();
                }
                else
                {
                    file = new FileStream(@"../../config/patients.json", FileMode.Open);
                    reader = new StreamReader(file);
                    string line = reader.ReadLine();

                    if (line != null && line != "")
                        output = JsonConvert.DeserializeObject<List<Patient>>(line);
                    else
                        output = new List<Patient>();
                    reader.Close();
                    file.Close();
                }
            } catch (Exception e)
            {
                Console.WriteLine(e);
                reader.Close();
                file.Close();
                return new List<Patient>();
            }
            return output;
        }

        public static List<string> GetAllOutputDataFileNames()
        {
            List<string> output = new List<string>();
            DirectoryInfo directoryInfo = new DirectoryInfo(@"../../output");
            FileInfo[] files = directoryInfo.GetFiles("*.json");

            foreach (FileInfo f in files)
            {
                output.Add(f.Name);
            }
            return output;
        }
    }
}
