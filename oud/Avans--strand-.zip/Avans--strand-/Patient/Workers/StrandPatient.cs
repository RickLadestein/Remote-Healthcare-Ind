﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Patient.TCPConnection;
using Patient.Bike;
using Newtonsoft.Json;
using System.Threading;

namespace Patient.Workers
{
    class StrandPatient : ITCPDataListener, IBikeMeasurementListener
    {
        const string IP_ADRESS = "145.49.33.3";
        const int PORT = 25565;

        private BikeHandler handler;
        private Connection connection;

        private UI clientinterface;

        private bool joined = false;
        public StrandPatient()
        {
            InitializeStrandPatient();
            SendIntent();
            clientinterface = new UI();
            clientinterface.ShowDialog();
        }

        private void InitializeStrandPatient()
        {
            connection = new Connection(IP_ADRESS, PORT, this);
            handler = BikeHandler.GetInstance();
            if (!handler.alive)
            {
                connection.CloseConnection();
                Console.WriteLine("COULD NOT FIND BIKE, PRESS KEY TO CLOSE");
                Console.ReadKey();
                Environment.Exit(-1);
            }
            handler.AddSubscriber(this);
        }

        private void SendIntent()
        {
            connection.SendData(JsonConvert.SerializeObject(new
            {
                command = "client/intent",
                data = new
                {
                    id = "PATIENT"
                }
            }));
            AwaitResponse();
        }

        public void StopPatient()
        {
            handler.ClosePort();
            connection.CloseConnection();
        }

        public void HandleTCPData(string data)
        {
            //TODO parse the incomming data
            string power;
            string time;
            dynamic message = JsonConvert.DeserializeObject(data);
            string command = message.command;
            switch (command)
            {
                case "server/accepted":
                    this.joined = true;
                    break;
                case "server/denied":
                    this.StopPatient();
                    Console.WriteLine(message.data.info + " closing patient");
                    break;
                case "doctor/starttest":
                    handler.SetBikeSettings(25, new TimeSpan(0, 2, 0));
                    handler.StartTimer();
                    break;
                case "doctor/stoptest":
                    handler.ResetBike();
                    handler.StopTimer();
                    break;
                case "doctor/bikesettings":
                    power = message.data.power;
                    time = message.data.time;
                    handler.SetBikeSettings(int.Parse(power), TimeSpan.Parse("00:" + time));
                    break;
                case "doctor/resetbike":
                    handler.ResetBike();
                    break;
                case "doctor/setpower":
                    power = message.data.power;
                    handler.AddPower(power);
                    break;
                case "doctor/settime":
                    time = message.data.time;
                    handler.SetTime(TimeSpan.Parse(time));
                    break;
            }
        }


        #region Listeners
        public void OnDataReceived(string data)
        {
            HandleTCPData(data);
        }

        public void AwaitResponse()
        {
            while (!joined)
            {
                Thread.Sleep(100);
            }
        }

        public void OnMeasurementReceived(BikeMeasurement measurement)
        {
            //Console.Clear();
            string data = JsonConvert.SerializeObject(new
            {
                command = "patient/bikedata",
                data = measurement
            }); // make a json command from the package
            connection.SendData(data); // send the json string to the connection
            Console.WriteLine(measurement.ToString());
            Console.WriteLine("");

            clientinterface.SetHeartRate(measurement.Bpm);
            if(measurement.Bpm < 120)
            {
                clientinterface.SetMessage("GO FASTER");
            }
        }
        #endregion
    }
}
