﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net.Security;
using System.IO;

namespace Patient.TCPConnection
{
    class StreamListener
    {
        private Connection connection;
        private Stream stream;
        private StreamReader reader;
        private TcpClient client;
        private ITCPDataListener listener;

        public bool alive;

        public StreamListener(Connection c, Stream stream, ITCPDataListener listener)
        {
            this.connection = c;
            this.stream = stream;
            this.listener = listener;
            this.client = c.connection;
            this.reader = new StreamReader(stream); // put the ssl stream into a new reader
            alive = true;
        }

        public void Start()
        {
            while (alive)
            {
                try
                {
                    string message = reader.ReadLine();
                    if (listener != null)
                    {
                        Console.WriteLine("received:" + message);
                        listener.OnDataReceived(message);
                    }
                    else
                    {
                        Console.WriteLine("Received data but listener is null");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error in receiving messages: " + ex);
                    this.alive = false;
                    connection.alive = false;
                }
            }
        }
    }
}
