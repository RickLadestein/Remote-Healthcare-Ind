﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patient.Bike
{
    public partial class UI : Form
    {
        public UI()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        public void SetMessage(string message)
        {
            Invoke(new Action(() => MessageLabel.Text = message));
        }

        public void SetHeartRate(int count)
        {
            Invoke(new Action(() => heartratelabel.Text = $"HB: {count} BPM"));
        }
    }
}
