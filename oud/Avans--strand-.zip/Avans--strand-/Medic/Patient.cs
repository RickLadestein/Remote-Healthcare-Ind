﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Medic.Bike;
using SharedClasses;
namespace Medic
{
    public class Patient
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public bool Gender { get; set; }
        public int Weight { get; set; }

        public List<MeasurementCollection> Measurements { get; set; }

        public Patient()
        {
            Name = "";
            Age = -1;
            Gender = true;
            Weight = 50;
        }
        public Patient(string name, int age, int weight,bool gender)
        {
            Name = name;
            Age = age;
            Gender = gender;
            Weight = weight;
        }
    }
}
