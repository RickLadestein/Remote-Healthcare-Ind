﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Net.Sockets;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.IO;

namespace Medic.TCPConnection
{
    public class Connection
    {
        private string ip;
        private int port;

        private Stream dataStream;
        public TcpClient connection;
        private StreamWriter writer;

        private Thread worker;
        private StreamListener streamlistener;
        private ITCPDataListener listener;


        public bool alive;

        public Connection(string ip, int port, ITCPDataListener listener)
        {
            this.listener = listener;
            this.ip = ip;
            this.port = port;

            ConnectToServer();
        }

        public void SendData(string data)
        {

            try
            {
                if (writer != null && alive)
                {
                    Console.WriteLine("sent: " + data);
                    writer.WriteLine(data);
                    writer.Flush();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Could not send message: " + ex);
                this.alive = false;
            }
        }

        #region ConnectionToServer
        private void StartConnectionWorker()
        {
            streamlistener = new StreamListener(this, dataStream, listener);
            worker = new Thread(new ThreadStart(streamlistener.Start));
            worker.Start();
        }

        public void SendIntend()
        {
            this.SendData(JsonConvert.SerializeObject(new
            {
                command = "client/intent",
                data = new
                {
                    id = "DOCTOR"
                }
            }));
        }


        public void SendBikeSettings(int power, TimeSpan time)
        {
            this.SendData(JsonConvert.SerializeObject(new
            {
                command = "doctor/bikesettings",
                data = new {
                    power = power,
                    time = time
                }
            }));
        }

        public void SendBikePower(int increment)
        {
            this.SendData(JsonConvert.SerializeObject(new
            {
                command = "doctor/setpower",
                data = new
                {
                    power = increment,
                }
            }));

        }

        public void SendBikeTime(TimeSpan t)
        {
            this.SendData(JsonConvert.SerializeObject(new
            {
                command = "doctor/settime",
                data = new
                {
                    time = t
                }
            }));
        }
        public void CloseConnection()
        {
            try
            {
                SendData(JsonConvert.SerializeObject(new
                {
                    command = "client/disconnect"

                }));
                Thread.Sleep(1000);
                streamlistener.alive = false;
                dataStream.Flush();
                dataStream.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Could not close connection: " + ex);
            }
        }


        private void ConnectToServer()
        {
            try
            {
                Console.WriteLine("--Connecting to Server");
                connection = new TcpClient(ip, port);
                Console.WriteLine("--Connected to server");
                dataStream = connection.GetStream();
                writer = new StreamWriter(dataStream);
                alive = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("--Could not connect to server: " + ex);
                return;
            }
            StartConnectionWorker();
        }
        #endregion
    }
}
