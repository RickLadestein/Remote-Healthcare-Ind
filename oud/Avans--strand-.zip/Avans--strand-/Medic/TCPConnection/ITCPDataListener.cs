﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Medic.TCPConnection
{
    public interface ITCPDataListener
    {
        void OnDataReceived(string data, Connection c);
    }
}
