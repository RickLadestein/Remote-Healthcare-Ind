﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Newtonsoft.Json;
using System.Threading.Tasks;
using Medic.Bike;

namespace Medic.Json
{
    class JsonFileHandler
    {

        public static bool WriteBikeDataToOutput(List<BikeMeasurement> datapoints, string outputfilename)
        {
            if (File.Exists(@"../../output/" + outputfilename))
            {
                return false;
            }

            try
            {
                FileStream file = new FileStream(@"../../output/" + outputfilename, FileMode.Create);
                StreamWriter writer = new StreamWriter(file);
                writer.WriteLine(JsonConvert.SerializeObject(datapoints));
                writer.Close();
                file.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return false;
            }
            return true;
        }

        public static bool WritePatientDataToOutput(List<Patient> p, string outputfilename)
        {
            if (File.Exists(@"../../output/" + outputfilename))
            {
                return false;
            }

            try
            {
                FileStream file = new FileStream(@"../../output/" + outputfilename, FileMode.Create);
                StreamWriter writer = new StreamWriter(file);
                writer.WriteLine(JsonConvert.SerializeObject(p));
                writer.Close();
                file.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return false;
            }
            return true;
        }
    }
}
