﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Medic.Interfaces
{
    partial class LoginGui : Form
    {
        public LoginGui()
        {
            InitializeComponent();
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            // Login code

            if (txtUsername.Text == "" && txtPassword.Text == "")
            {
                new AstrandGui(txtUsername.Text).Show();
                this.Hide();
                this.Visible = false;
            }
            else
            {
                MessageBox.Show("Wrong password!");
                ResetForm();
            }
        }

        private void ResetForm()
        {
            txtUsername.Text = "";
            txtPassword.Text = "";
            txtUsername.Focus();
        }
    }
}
