﻿using Medic.TCPConnection;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Medic.Interfaces
{
    public partial class SwitchUserGui : Form
    {
        Patient selectedPatient;
        List<Patient> allPatients;

        public SwitchUserGui(Patient currentPatient, List<Patient> allPatients)
        {
            this.allPatients = allPatients;
            InitializeComponent();
            SetPatient(new Patient());
            LoadPatients();
        }

        private void SetPatient(Patient newPatient)
        {
            this.selectedPatient = newPatient;

            lblName.Text = "Name: " + newPatient.Name;
            lblAge.Text = "Age: " + newPatient.Age;
            lblGender.Text = "Gender: ";

            if (newPatient.Gender)
                lblGender.Text += "Male";
            else
                lblGender.Text += "Female";
        }

        private void LoadPatients()
        {
            cbxPatients.Items.Clear();
            string[] names = new string[allPatients.Count];
            for (int i = 0; i < allPatients.Count; i++)
            {
                names[i] = allPatients[i].Name;
            }
            cbxPatients.Items.AddRange(names);
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            AstrandGui parent = (AstrandGui)this.Owner;
            parent.NotifyNewPatient(selectedPatient);
            this.Dispose();
        }

        private void cbxPatients_SelectedIndexChanged(object sender, EventArgs e)
        {
            SetPatient(allPatients[cbxPatients.SelectedIndex]);
        }
    }
}
