﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Medic.Interfaces
{
    partial class FileSelecterUi : Form
    {

        List<string> filenames;
        AstrandGui parent;
        public FileSelecterUi(List<string> filenames, AstrandGui parent)
        {
            InitializeComponent();
            this.filenames = filenames;
            this.parent = parent;
            FillCollectionbox();
            this.Focus();
        }

        private void FillCollectionbox()
        {
            FileCollectionBox.DataSource = filenames;
        }

        private void FileCollectionBox_DoubleClick(object sender, EventArgs e)
        {
            int selection = FileCollectionBox.SelectedIndex;
            parent.LaunchDataViewer(filenames[selection]);
            this.Dispose();
        }
    }
}
