﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Medic.Bike;
using LiveCharts;
using LiveCharts.WinForms;
using LiveCharts.Wpf;

namespace Medic.Interfaces
{
    partial class DataViewer : Form
    {
        private List<BikeMeasurement> measurements;
        private Patient currentpatient;
        private List<int> hbdata;
        private List<int> temphbdata;
        private bool isReliable = false;
        private double avghb;

        private double VO2MAX;


        private double[,] ageMultipliers = new double[,]
        {
            {15, 1.10 },
            {25, 1.00 },
            {35, 0.87 },
            {40, 0.83 },
            {45, 0.78 },
            {50, 0.75 },
            {55, 0.71 },
            {60, 0.68 },
            {65, 0.65 }
        };
        private double[,] maxHeartRateMultipliers = new double[,]
        {
            {210, 1.12 },
            {200, 1.00 },
            {190, 0.93 },
            {180, 0.83 },
            {170, 0.75 },
            {160, 0.69 },
            {150, 0.34 }
        };


        public DataViewer(List<BikeMeasurement> measurements, Patient patient)
        {
            InitializeComponent();
            this.measurements = measurements;
            temphbdata = new List<int>();
            this.currentpatient = patient;
            CollectHBdata();
            CheckHBdata();
            CalculateVO2();
            showData();
        }

        public DataViewer(List<BikeMeasurement> measurements, List<int> heartbeatdata,Patient patient)
        {
            InitializeComponent();
            this.measurements = measurements;
            this.currentpatient = patient;
            hbdata = heartbeatdata;
            CheckHBdata();
            CalculateVO2();
            showData();
        }

        private void showData()
        {

            //Set data in livechart
            livechart1.Series = new SeriesCollection(){
                new LineSeries
                {
                    Values = CopyHeartbeatDataToChartvals(this.measurements)
                },
                new LineSeries
                {
                    Values = CopyPowerDataToChartvals(this.measurements)
                }
            };


            //Set the data integrity
            if (isReliable)
                integrityLabel.Text = "OK";
            else
                integrityLabel.Text = "UNSTABLE";

            hbLabel.Text = "AVG.HB: " + (int) avghb + " BPM";
            vo2Label.Text = "VO2MAX: " + (int) VO2MAX;

            this.Text = $"Patient: {currentpatient.Name} | Age: {currentpatient.Age}";

        }

        private ChartValues<double> CopyHeartbeatDataToChartvals(List<BikeMeasurement> e)
        {
            ChartValues<double> temp = new ChartValues<double>();
            foreach (BikeMeasurement measurement in e)
                temp.Add(measurement.Bpm);
            return temp;
        }

        private ChartValues<double> CopyPowerDataToChartvals(List<BikeMeasurement> e)
        {
            ChartValues<double> temp = new ChartValues<double>();
            foreach (BikeMeasurement measurement in e)
                temp.Add(measurement.Resistance);
            return temp;
        }

        private void CalculateVO2()
        {
            double total = 0;
            foreach (int i in hbdata)
                total += i;
            total = total / hbdata.Count;
            avghb = total;
            int gendernumber = 0;
            if (currentpatient.Gender)
                gendernumber = 1;

            double VO2 = (1.8 * total) / currentpatient.Weight;

            VO2MAX = VO2 * ((220 - currentpatient.Age - 73 - (gendernumber * 10)) / (total - 73 - (gendernumber * 10)));

            int multiplier = (int) Math.Floor(currentpatient.Age * 0.18d) - 1;
            VO2MAX = VO2MAX * ageMultipliers[multiplier, 1];

        }

        private void CollectHBdata()
        {
            hbdata = new List<int>();

            foreach(BikeMeasurement m in measurements)
            {
                temphbdata.Add(m.Bpm);
            }

            // normalize data
            if (measurements.Count < 420)
            {
                for (int i = 0; i < 420 - measurements.Count; i++)
                {
                    temphbdata.Add(measurements[measurements.Count - 1].Bpm);
                }
            }
            // making sure that hbdata is empty
            hbdata.Clear();

            hbdata.Add(temphbdata[120]);
            hbdata.Add(temphbdata[180]);
            hbdata.Add(temphbdata[240]);

            hbdata.Add(temphbdata[255]);
            hbdata.Add(temphbdata[270]);
            hbdata.Add(temphbdata[285]);
            hbdata.Add(temphbdata[300]);
            hbdata.Add(temphbdata[315]);
            hbdata.Add(temphbdata[330]);
            hbdata.Add(temphbdata[345]);
            hbdata.Add(temphbdata[360]);
        }

        private void CheckHBdata()
        {
            int prevdata;
            int currentdata;

            prevdata = hbdata[0];
            for (int i = 1; i < hbdata.Count; i++)
            {
                currentdata = hbdata[i];
                if(prevdata - currentdata < 6 && prevdata - currentdata > -6)
                {
                    isReliable = true;
                } else
                {
                    isReliable = false;
                }
            }
        }
    }
}
