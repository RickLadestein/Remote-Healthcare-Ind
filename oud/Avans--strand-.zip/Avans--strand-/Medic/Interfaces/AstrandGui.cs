﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using LiveCharts;
using LiveCharts.WinForms;
using LiveCharts.Wpf;
using Medic.Bike;
using Newtonsoft.Json.Linq;
using Medic.TCPConnection;
using Newtonsoft.Json;
using System.Timers;
using System.Threading;



namespace Medic.Interfaces
{
    partial class AstrandGui : Form, ITCPDataListener
    {
        private Connection connection;
        private System.Timers.Timer secondTimer;
        int increment = 0;
        Patient currentPatient= new Patient();

        private int elapsedSeconds = 0;
        private int lastHeartbeat = 0;
        private List<int> heartbeats;

        private bool measuring;
        private bool response_collected;

        private List<BikeMeasurement> measurements = new List<BikeMeasurement>();

        

        public AstrandGui(string medicUsername)
        {
            InitializeComponent();
            StopButton.Enabled = false;
            response_collected = false;
            InitiateGraph();
            this.connection = new Connection("localhost", 25565, this);
            connection.SendIntend();
        }

        private void setupTimer()
        {
            secondTimer = new System.Timers.Timer(1000);
            secondTimer.AutoReset = true;
            secondTimer.Elapsed += new ElapsedEventHandler(OnTimerTick);
            secondTimer.Start();
        }


        private void pgbTestProgress_Click(object sender, EventArgs e)
        {
            new System.Threading.Thread(new System.Threading.ThreadStart(StartTest)).Start();
        }

        private void InitiateGraph()
        {
            SeriesCollection s = new SeriesCollection
            {
                new LineSeries
                {
                    Values = CopyHeartbeatDataToChartvals(this.measurements)
                },
                new LineSeries
                {
                    Values = CopyPowerToChartvals(this.measurements)
                }
            };
            livechart1.Series = s;
        }

        private ChartValues<double> CopyHeartbeatDataToChartvals(List<BikeMeasurement> e)
        {
            ChartValues<double> temp = new ChartValues<double>();
            foreach (BikeMeasurement measurement in e)
                temp.Add(measurement.Bpm);
            return temp;
        }

        private ChartValues<double> CopyPowerToChartvals(List<BikeMeasurement> e)
        {
            ChartValues<double> temp = new ChartValues<double>();
            foreach (BikeMeasurement measurement in e)
                temp.Add(measurement.Resistance);
            return temp;
        }

        private void StartTest()
        {
            connection.SendBikeSettings(50, new TimeSpan(0, 2, 0));
            setupTimer();
            /* 2 minuten warming up
             * Laag wattage
             */

            /* 4 minuten test:
             * 
             * Langzaam power omhoog laten gaan 
             * Beginnen op 50 watt
             * Mannen met 50 watt per stap
             * Vrouwen 25 watt per stap
             * Zwaarte opvoeren tot hartslag tussen 120 en 170 bpm
             * 
             * RPM tussen 50 en 60 houden
             * Iedere minuut heartrate meten
             * 
             * Laatste 2 minuten heartrate iedere 15 sec meten
             * indien ongeveer constant wordt gemiddelde rate van laatste 2 min gerekend
             */

            /* Cooling down
             * probs laag wattage weer
             */
        }

        private void OnTimerTick(object sender, ElapsedEventArgs e)
        {
            pgbTestProgress.Increment(1);
            elapsedSeconds++;

            if(elapsedSeconds >= 120 && elapsedSeconds <= 360)
            {
                //count heartbeat first once every minute
                if (elapsedSeconds == 180 || elapsedSeconds == 240)
                    heartbeats.Add(lastHeartbeat);

                //count heatbeat after 2 minutes every 15 seconds
                if (elapsedSeconds > 240)
                {
                    int number = (elapsedSeconds - 240) % 15;
                    if (number == 0)
                        heartbeats.Add(lastHeartbeat);
                }

                //TODO increase/decrease bikepower according to bikevalues
                if(elapsedSeconds % 2 == 0)
                {
                    AdjustPowerToHeartbeat(lastHeartbeat);
                }
            }

            if (elapsedSeconds >= 360)
                if (elapsedSeconds % 10 == 0)
                    connection.SendBikePower(-50);
            if (elapsedSeconds == 420)
            {
                secondTimer.Stop();
                connection.SendData(JsonConvert.SerializeObject(new
                {
                    command = "doctor/stoptest"
                }));
                elapsedSeconds = 0;
            }
        }

        private void AdjustPowerToHeartbeat(int bpm)
        {
            if (!(bpm > 120 && bpm < 170))
                if (bpm < 120)
                    if (currentPatient.Gender)
                        connection.SendBikePower(50);
                    else
                        connection.SendBikePower(25);
                else if (bpm > 170)
                    if (currentPatient.Gender)
                        connection.SendBikePower(-50);
                    else
                        connection.SendBikePower(-25);
        }


        public void NotifyNewPatient(Patient newPatient, bool state = false)
        {
            currentPatient = newPatient;
            nameLabel.Text = "Name: " + currentPatient.Name;
            ageLabel.Text = "Age: " + currentPatient.Age;
            if (currentPatient.Gender)
                genderLabel.Text = "Gender: Male";
            else
                genderLabel.Text = "Gender: Female";

            if (!state)
            {
                connection.SendData(JsonConvert.SerializeObject(new
                {
                    command = "doctor/patientname",
                    data = new
                    {
                        name = newPatient.Name
                    }
                }));
            }
        }

        public void LaunchDataViewer(string filename)
        {
            Invoke(new Action(() =>
            {
                connection.SendData(JsonConvert.SerializeObject(new
                {
                    command = "watcher/requestdata",
                    data = new
                    {
                        file = filename
                    }
                }));
            }));
        }


        private void Startbutton_Click(object sender, EventArgs e)
        {
            connection.SendData(JsonConvert.SerializeObject(new
            {
                command = "doctor/starttest"
            }));

            AwaitResponse();
            Startbutton.Enabled = false;
            StopButton.Enabled = true;
            DataButton.Enabled = false;
        }

        private void StopButton_Click(object sender, EventArgs e)
        {
            connection.SendData(JsonConvert.SerializeObject(new
            {
                command = "doctor/stoptest"
            }));

            AwaitResponse();
            secondTimer.Stop();
            elapsedSeconds = 0;
            measurements.Clear();
            pgbTestProgress.Value = 0;
            Startbutton.Enabled = true;
            StopButton.Enabled = false;
            DataButton.Enabled = true;
        }

        private void DataButton_Click(object sender, EventArgs e)
        {
            connection.SendData(JsonConvert.SerializeObject(new
            {
                command = "watcher/requestfilelist"
            }));
        }

        private void btnChangePatient_Click(object sender, EventArgs e)
        {
            connection.SendData(JsonConvert.SerializeObject(new
            {
                command = "client/getallpatients"
            }));
        }

        private void generatePatients()
        {
            List<Patient> patients = new List<Patient>();
            patients.Add(new Patient("Rikkert", 19, 100, true));
            patients.Add(new Patient("Yannick", 21, 74, true));
            patients.Add(new Patient("Yohan", 27, 90, true));
            patients.Add(new Patient("Jan", 44, 160, true));
            patients.Add(new Patient("Kniezo", 21, 60, true));

            Json.JsonFileHandler.WritePatientDataToOutput(patients, "patients.json");
        }

        private void AwaitResponse()
        {
            while (!response_collected)
            {
                Thread.Sleep(10);
            }
        }

        

        private void HandleBikePackage(JObject data)
        {
            BikeMeasurement measurement = data.ToObject<BikeMeasurement>();
            measurements.Add(measurement);
            lastHeartbeat = measurement.Bpm;
            Invoke(new Action(() =>
            {
                ChangeLabels($"Heartbeat: {measurement.Bpm} BPM",$"Power: {measurement.Resistance} NM",$"SPEED: {measurement.Speed} m/s");
                InitiateGraph();
            }));
        }

        public void ChangeLabels(string hb, string bp, string bs)
        {
            heartbeatlabel.Text = hb;
            bikepowerlabel.Text = bp;
            bikespeedlabel.Text = bs;
        }

        private void HandleIncommingData(string data, Connection c)
        {
            string id;
            string info;
            JObject @object;
            JArray array;

            dynamic message = JsonConvert.DeserializeObject(data);
            string command = message.command;
            switch (command)
            {
                case "server/denied":
                    info = message.data.info;
                    MessageBox.Show(info, "Invalid Operation");
                    Invoke(new Action(() => {
                        Startbutton.Enabled = true;
                        StopButton.Enabled = false;
                        DataButton.Enabled = true;
                    }));

                    if (info.Contains("watcher"))
                        Invoke(new Action(() => { Startbutton.Enabled = false; }));
                    else if(info == "No patient is connected to the server")
                        Invoke(new Action(() => { NotifyNewPatient(new Patient(), true); }));
                    break;
                case "server/accepted":
                    response_collected = true;
                    string origin = message.data.origin;
                    if (origin == "doctor/starttest")
                        StartTest();
                    break;
                case "server/files":
                    array = message.data;
                    List<string> files = array.ToObject<List<string>>();
                    Invoke(new Action(() => { new FileSelecterUi(files, this).ShowDialog(); }));
                    break;
                case "server/data":
                    array = message.data;
                    List<BikeMeasurement> bikedata = array.ToObject<List<BikeMeasurement>>();
                    Invoke(new Action(() => { new DataViewer(bikedata, currentPatient).Show(); }));
                    break;
                case "server/patients":
                    array = message.data;
                    List<Patient> patients = array.ToObject<List<Patient>>();
                    Invoke(new Action(() => 
                    {
                        using (SwitchUserGui sugui = new SwitchUserGui(currentPatient, patients))
                        {
                            sugui.ShowDialog(this);
                        }
                        /*TODO add patientlistviewer here*/
                    }));
                    break;
                case "patient/bikedata":
                    @object = message.data;
                    HandleBikePackage(@object);
                    break;
            }
        }

        public void OnDataReceived(string data, Connection c)
        {
            Console.WriteLine(data);
            HandleIncommingData(data, c);
        }

        private void AstrandGui_FormClosing(object sender, FormClosingEventArgs e)
        {
            connection.CloseConnection();
            Environment.Exit(0);
        }
    }
}
