﻿namespace Medic.Interfaces
{
    partial class AstrandGui
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pgbTestProgress = new System.Windows.Forms.ProgressBar();
            this.heartbeatlabel = new System.Windows.Forms.Label();
            this.bikespeedlabel = new System.Windows.Forms.Label();
            this.bikepowerlabel = new System.Windows.Forms.Label();
            this.gbxRealTimeStats = new System.Windows.Forms.GroupBox();
            this.gbxPatientData = new System.Windows.Forms.GroupBox();
            this.btnChangePatient = new System.Windows.Forms.Button();
            this.nameLabel = new System.Windows.Forms.Label();
            this.genderLabel = new System.Windows.Forms.Label();
            this.ageLabel = new System.Windows.Forms.Label();
            this.Startbutton = new System.Windows.Forms.Button();
            this.StopButton = new System.Windows.Forms.Button();
            this.DataButton = new System.Windows.Forms.Button();
            this.livechart1 = new LiveCharts.WinForms.CartesianChart();
            this.gbxRealTimeStats.SuspendLayout();
            this.gbxPatientData.SuspendLayout();
            this.SuspendLayout();
            // 
            // pgbTestProgress
            // 
            this.pgbTestProgress.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pgbTestProgress.Location = new System.Drawing.Point(0, 0);
            this.pgbTestProgress.Maximum = 4200;
            this.pgbTestProgress.Name = "pgbTestProgress";
            this.pgbTestProgress.Size = new System.Drawing.Size(908, 10);
            this.pgbTestProgress.TabIndex = 0;
            this.pgbTestProgress.Click += new System.EventHandler(this.pgbTestProgress_Click);
            // 
            // heartbeatlabel
            // 
            this.heartbeatlabel.AutoSize = true;
            this.heartbeatlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.heartbeatlabel.Location = new System.Drawing.Point(3, 27);
            this.heartbeatlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.heartbeatlabel.Name = "heartbeatlabel";
            this.heartbeatlabel.Size = new System.Drawing.Size(157, 20);
            this.heartbeatlabel.TabIndex = 2;
            this.heartbeatlabel.Text = "Heart Rate:  {0} BPM";
            // 
            // bikespeedlabel
            // 
            this.bikespeedlabel.AutoSize = true;
            this.bikespeedlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bikespeedlabel.Location = new System.Drawing.Point(3, 47);
            this.bikespeedlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bikespeedlabel.Name = "bikespeedlabel";
            this.bikespeedlabel.Size = new System.Drawing.Size(157, 20);
            this.bikespeedlabel.TabIndex = 3;
            this.bikespeedlabel.Text = "Bike Speed: {1} RPM";
            // 
            // bikepowerlabel
            // 
            this.bikepowerlabel.AutoSize = true;
            this.bikepowerlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bikepowerlabel.Location = new System.Drawing.Point(3, 68);
            this.bikepowerlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bikepowerlabel.Name = "bikepowerlabel";
            this.bikepowerlabel.Size = new System.Drawing.Size(149, 20);
            this.bikepowerlabel.TabIndex = 4;
            this.bikepowerlabel.Text = "Bike Power: {2} watt";
            // 
            // gbxRealTimeStats
            // 
            this.gbxRealTimeStats.Controls.Add(this.heartbeatlabel);
            this.gbxRealTimeStats.Controls.Add(this.bikespeedlabel);
            this.gbxRealTimeStats.Controls.Add(this.bikepowerlabel);
            this.gbxRealTimeStats.Location = new System.Drawing.Point(6, 170);
            this.gbxRealTimeStats.Margin = new System.Windows.Forms.Padding(2);
            this.gbxRealTimeStats.Name = "gbxRealTimeStats";
            this.gbxRealTimeStats.Padding = new System.Windows.Forms.Padding(2);
            this.gbxRealTimeStats.Size = new System.Drawing.Size(172, 108);
            this.gbxRealTimeStats.TabIndex = 6;
            this.gbxRealTimeStats.TabStop = false;
            this.gbxRealTimeStats.Text = "Real-Time Statistics";
            // 
            // gbxPatientData
            // 
            this.gbxPatientData.Controls.Add(this.btnChangePatient);
            this.gbxPatientData.Controls.Add(this.nameLabel);
            this.gbxPatientData.Controls.Add(this.genderLabel);
            this.gbxPatientData.Controls.Add(this.ageLabel);
            this.gbxPatientData.Location = new System.Drawing.Point(6, 15);
            this.gbxPatientData.Margin = new System.Windows.Forms.Padding(2);
            this.gbxPatientData.Name = "gbxPatientData";
            this.gbxPatientData.Padding = new System.Windows.Forms.Padding(2);
            this.gbxPatientData.Size = new System.Drawing.Size(172, 119);
            this.gbxPatientData.TabIndex = 7;
            this.gbxPatientData.TabStop = false;
            this.gbxPatientData.Text = "Patient Data";
            // 
            // btnChangePatient
            // 
            this.btnChangePatient.Location = new System.Drawing.Point(4, 92);
            this.btnChangePatient.Margin = new System.Windows.Forms.Padding(2);
            this.btnChangePatient.Name = "btnChangePatient";
            this.btnChangePatient.Size = new System.Drawing.Size(164, 24);
            this.btnChangePatient.TabIndex = 8;
            this.btnChangePatient.Text = "Change patient";
            this.btnChangePatient.UseVisualStyleBackColor = true;
            this.btnChangePatient.Click += new System.EventHandler(this.btnChangePatient_Click);
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLabel.Location = new System.Drawing.Point(4, 25);
            this.nameLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(78, 20);
            this.nameLabel.TabIndex = 5;
            this.nameLabel.Text = "Name: {0}";
            // 
            // genderLabel
            // 
            this.genderLabel.AutoSize = true;
            this.genderLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.genderLabel.Location = new System.Drawing.Point(4, 46);
            this.genderLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.genderLabel.Name = "genderLabel";
            this.genderLabel.Size = new System.Drawing.Size(90, 20);
            this.genderLabel.TabIndex = 6;
            this.genderLabel.Text = "Gender: {1}";
            // 
            // ageLabel
            // 
            this.ageLabel.AutoSize = true;
            this.ageLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ageLabel.Location = new System.Drawing.Point(3, 66);
            this.ageLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ageLabel.Name = "ageLabel";
            this.ageLabel.Size = new System.Drawing.Size(65, 20);
            this.ageLabel.TabIndex = 7;
            this.ageLabel.Text = "Age: {2}";
            // 
            // Startbutton
            // 
            this.Startbutton.Location = new System.Drawing.Point(252, 396);
            this.Startbutton.Name = "Startbutton";
            this.Startbutton.Size = new System.Drawing.Size(328, 42);
            this.Startbutton.TabIndex = 9;
            this.Startbutton.Text = "Start test";
            this.Startbutton.UseVisualStyleBackColor = true;
            this.Startbutton.Click += new System.EventHandler(this.Startbutton_Click);
            // 
            // StopButton
            // 
            this.StopButton.Location = new System.Drawing.Point(586, 395);
            this.StopButton.Name = "StopButton";
            this.StopButton.Size = new System.Drawing.Size(310, 43);
            this.StopButton.TabIndex = 10;
            this.StopButton.Text = "Stop test";
            this.StopButton.UseVisualStyleBackColor = true;
            this.StopButton.Click += new System.EventHandler(this.StopButton_Click);
            // 
            // DataButton
            // 
            this.DataButton.Location = new System.Drawing.Point(6, 299);
            this.DataButton.Name = "DataButton";
            this.DataButton.Size = new System.Drawing.Size(172, 139);
            this.DataButton.TabIndex = 11;
            this.DataButton.Text = "View Data";
            this.DataButton.UseVisualStyleBackColor = true;
            this.DataButton.Click += new System.EventHandler(this.DataButton_Click);
            // 
            // livechart1
            // 
            this.livechart1.Location = new System.Drawing.Point(252, 40);
            this.livechart1.Name = "livechart1";
            this.livechart1.Size = new System.Drawing.Size(644, 331);
            this.livechart1.TabIndex = 12;
            this.livechart1.Text = "custom";
            // 
            // AstrandGui
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(908, 450);
            this.Controls.Add(this.livechart1);
            this.Controls.Add(this.DataButton);
            this.Controls.Add(this.StopButton);
            this.Controls.Add(this.Startbutton);
            this.Controls.Add(this.gbxPatientData);
            this.Controls.Add(this.gbxRealTimeStats);
            this.Controls.Add(this.pgbTestProgress);
            this.Name = "AstrandGui";
            this.Text = "Avans- Åstrand Test - Medic";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AstrandGui_FormClosing);
            this.gbxRealTimeStats.ResumeLayout(false);
            this.gbxRealTimeStats.PerformLayout();
            this.gbxPatientData.ResumeLayout(false);
            this.gbxPatientData.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ProgressBar pgbTestProgress;
        private System.Windows.Forms.Label heartbeatlabel;
        private System.Windows.Forms.Label bikespeedlabel;
        private System.Windows.Forms.Label bikepowerlabel;
        private System.Windows.Forms.GroupBox gbxRealTimeStats;
        private System.Windows.Forms.GroupBox gbxPatientData;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label genderLabel;
        private System.Windows.Forms.Label ageLabel;
        private System.Windows.Forms.Button Startbutton;
        private System.Windows.Forms.Button StopButton;
        private System.Windows.Forms.Button DataButton;
        private LiveCharts.WinForms.CartesianChart livechart1;
        private System.Windows.Forms.Button btnChangePatient;
    }
}