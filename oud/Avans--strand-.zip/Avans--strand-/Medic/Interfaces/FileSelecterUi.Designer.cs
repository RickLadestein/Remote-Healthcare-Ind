﻿namespace Medic.Interfaces
{
    partial class FileSelecterUi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.FileCollectionBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(241, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "Please select a file to view";
            // 
            // FileCollectionBox
            // 
            this.FileCollectionBox.FormattingEnabled = true;
            this.FileCollectionBox.Location = new System.Drawing.Point(16, 62);
            this.FileCollectionBox.Name = "FileCollectionBox";
            this.FileCollectionBox.Size = new System.Drawing.Size(283, 355);
            this.FileCollectionBox.TabIndex = 1;
            this.FileCollectionBox.DoubleClick += new System.EventHandler(this.FileCollectionBox_DoubleClick);
            // 
            // FileSelecterUi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(313, 432);
            this.Controls.Add(this.FileCollectionBox);
            this.Controls.Add(this.label1);
            this.Name = "FileSelecterUi";
            this.Text = "FileSelecterUi";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox FileCollectionBox;
    }
}