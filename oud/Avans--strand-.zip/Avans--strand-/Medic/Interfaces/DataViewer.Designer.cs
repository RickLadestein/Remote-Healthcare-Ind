﻿namespace Medic.Interfaces
{
    partial class DataViewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.livechart1 = new LiveCharts.WinForms.CartesianChart();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.integrityLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.vo2Label = new System.Windows.Forms.Label();
            this.hbLabel = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // livechart1
            // 
            this.livechart1.Location = new System.Drawing.Point(212, 12);
            this.livechart1.Name = "livechart1";
            this.livechart1.Size = new System.Drawing.Size(576, 426);
            this.livechart1.TabIndex = 0;
            this.livechart1.Text = "cartesianChart1";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.integrityLabel);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(3, 338);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 100);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Status";
            // 
            // integrityLabel
            // 
            this.integrityLabel.AutoSize = true;
            this.integrityLabel.Location = new System.Drawing.Point(59, 51);
            this.integrityLabel.Name = "integrityLabel";
            this.integrityLabel.Size = new System.Drawing.Size(70, 15);
            this.integrityLabel.TabIndex = 1;
            this.integrityLabel.Text = "UNSTABLE";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25743F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(37, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(132, 25);
            this.label3.TabIndex = 0;
            this.label3.Text = "INTEGRITY";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.vo2Label);
            this.groupBox2.Controls.Add(this.hbLabel);
            this.groupBox2.Location = new System.Drawing.Point(3, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(211, 100);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Info";
            // 
            // vo2Label
            // 
            this.vo2Label.AutoSize = true;
            this.vo2Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25743F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vo2Label.Location = new System.Drawing.Point(5, 62);
            this.vo2Label.Name = "vo2Label";
            this.vo2Label.Size = new System.Drawing.Size(136, 25);
            this.vo2Label.TabIndex = 1;
            this.vo2Label.Text = "VO2MAX: {}";
            // 
            // hbLabel
            // 
            this.hbLabel.AutoSize = true;
            this.hbLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25743F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hbLabel.Location = new System.Drawing.Point(7, 28);
            this.hbLabel.Name = "hbLabel";
            this.hbLabel.Size = new System.Drawing.Size(196, 25);
            this.hbLabel.TabIndex = 0;
            this.hbLabel.Text = "AVG HB: {1} BPM";
            // 
            // DataViewer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.livechart1);
            this.Name = "DataViewer";
            this.Text = "DataViewer";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private LiveCharts.WinForms.CartesianChart livechart1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label vo2Label;
        private System.Windows.Forms.Label hbLabel;
        private System.Windows.Forms.Label integrityLabel;
        private System.Windows.Forms.Label label3;
    }
}