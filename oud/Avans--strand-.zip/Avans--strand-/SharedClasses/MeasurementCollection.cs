﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SharedClasses
{
    public class MeasurementCollection
    {
        /// <summary>
        /// The collection of measurements
        /// </summary>
        public List<BikeMeasurement> Measurements { get; set; }

        /// <summary>
        /// The timestamp for the start of the recording
        /// </summary>
        public DateTime TimeStamp { get; set; }

        public MeasurementCollection(List<BikeMeasurement> measurements, DateTime timestamp)
        {
            this.Measurements = measurements;
            this.TimeStamp = timestamp;
        }
    }
}
